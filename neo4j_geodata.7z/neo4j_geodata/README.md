Geodata managing using Neo4J
